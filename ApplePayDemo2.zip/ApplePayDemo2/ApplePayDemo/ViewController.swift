//
//  ViewController.swift
//  ApplePayDemo
//
//  Created by Bandish on 23/11/17.
//  Copyright © 2017 Bandish. All rights reserved.
//

import UIKit
import PassKit
import Alamofire
import MBProgressHUD

class ViewController: UIViewController {
    var paymentRequest = PKPaymentRequest()
    fileprivate var hud: MBProgressHUD!
    fileprivate var alert: UIAlertController!

    // Mobile Payments Demo Server
    fileprivate let DemoServerURLBase = "https://api.na.bambora.com/v1/payments"
//    let PASSCODE = "Passcode MzAwMjExMDczOkZBMTRCNEFCQTFFMTQwOTM5OEI5QjFBRjMzMzM4NUNG"
    let PASSCODE2 = "Passcode MzAwMjA1MTk5OjJDRjkzODdDOEYzNjRDNjdBMTcyNkVFMDE3NzAxMkYz"
    //fileprivate let DemoServerURLBase = "http://merchant-api-demo.us-west-2.elasticbeanstalk.com/process-payment/apple-pay"
    // Apple Pay Merchant Identifier
    fileprivate let ApplePayMerchantID = "merchant.com.gatewaytechnolabs.aromaDemoDev"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        

    }

    func itemToSell(shipping: Double) -> [PKPaymentSummaryItem]
    {
        let item = PKPaymentSummaryItem(label: "Card amount", amount: 90.00)
        let discount = PKPaymentSummaryItem(label: "Discount", amount: -10.0)
        let shippingCharge = PKPaymentSummaryItem(label: "Shipping", amount: NSDecimalNumber(string: "\(shipping)"))
        let totalAmount = item.amount.adding(discount.amount).adding(shippingCharge.amount)
        let totalPrice = PKPaymentSummaryItem(label: "total amount", amount: totalAmount)
        return [item, discount, shippingCharge, totalPrice]
    }
    
    func paymentProcess() {
        let paymentNetwork = [PKPaymentNetwork.amex, .masterCard, .visa]
        if PKPaymentAuthorizationController.canMakePayments(usingNetworks: paymentNetwork){
            paymentRequest.currencyCode = "USD"
            paymentRequest.countryCode = "US"
            paymentRequest.merchantIdentifier = "merchant.com.gatewaytechnolabs.aromaDemoDev"
            paymentRequest.merchantCapabilities = .capability3DS
            paymentRequest.supportedNetworks = paymentNetwork
            paymentRequest.requiredShippingAddressFields = .all
            paymentRequest.paymentSummaryItems = self.itemToSell(shipping: 9.99)
            
            let sameDayShipping = PKShippingMethod(label: "Same Day Shipping", amount: NSDecimalNumber(string: "20"))
            sameDayShipping.identifier = "sameDayShipping"
            sameDayShipping.detail = "Item guaranteed to deliverd on the same day"
            
            
            let twoDayShipping = PKShippingMethod(label: "twoDayShipping Shipping", amount: NSDecimalNumber(string: "10"))
            twoDayShipping.identifier = "twoDayShipping"
            twoDayShipping.detail = "Arrives in 2 bussiness day"
            
            let freeShipping = PKShippingMethod(label: "Free Shipping", amount: NSDecimalNumber(string: "0"))
            freeShipping.identifier = "freeshipping"
            freeShipping.detail = "Arrives in 6-8 weeks"
            
            paymentRequest.shippingMethods = [sameDayShipping, twoDayShipping, freeShipping]
            
            let applePayVC = PKPaymentAuthorizationViewController(paymentRequest: paymentRequest)
            applePayVC.delegate = self
            self.present(applePayVC, animated: true, completion: nil)
        }
        else {
            let alert = UIAlertController(title: "Demo",
                                          message: "apple pay is not configured or not available",
                                          preferredStyle: UIAlertControllerStyle.alert)
            let cancelAction = UIAlertAction(title: "OK",
                                             style: .cancel, handler: nil)
            alert.addAction(cancelAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnApplePayPressed(_ sender: Any) {
        self.paymentProcess()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
}

extension ViewController: PKPaymentAuthorizationViewControllerDelegate{
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didAuthorizePayment payment: PKPayment, completion: @escaping (PKPaymentAuthorizationStatus) -> Void) {
        
        
        let token = payment.token
        let displayName = token.paymentMethod.displayName
        let typeName = token.paymentMethod.type.rawValue
//        let network = token.paymentMethod.network?._rawValue
        let identifier = token.transactionIdentifier
        
        
        let paymentData = token.paymentData
        let b64TokenStr = paymentData.base64EncodedString(options: NSData.Base64EncodingOptions(rawValue: 0))
        
        print("displayName:: \(displayName)")
        print("typeName::: \(typeName)")
//        print("network:::\(network)")
        print("identifier:::\(identifier)")
        print("b64TokenStr : \(b64TokenStr)")
        
        
//        self.alert = UIAlertController.init(title: "Mobile Payments", message: "\(b64TokenStr)", preferredStyle: .alert)
//        let okAction = UIAlertAction(title: "OK", style: .default, handler: { (alert: UIAlertAction) in
//            self.dismiss(animated: true, completion: nil)
//        })
//        self.alert.addAction(okAction)
        
        
        
//        var parameters = [
//            "amount": "1000",
//            "transaction-type": "apple_pay",
//            "apple_pay":[
//                "payment_token": "ahdkfha456ahiu",
//                "apple_pay_merchant_id": ApplePayMerchantID,
//                "complete": true
//                ]
//            ] as [String : Any]
        
        
        var parameters = [
            "amount": "1000",
            "payment_method": "apple_pay",
            "apple_pay": [
                "apple_pay_merchant_id": ApplePayMerchantID,
                "payment_token": b64TokenStr,
                "complete": true
            ]
        ] as [String : Any]
        
        
        // Get shipping and billing address fields
        if let shippingContact = payment.shippingContact {
            if let email = shippingContact.emailAddress {
                print("shipping email: \(email)")
            }
            
            if let dict = self.convertToAddressDictionary(contact: shippingContact) {
                parameters["shipping"] = dict
            }
        }
        
        if let billingContact = payment.billingContact {
            if let dict = self.convertToAddressDictionary(contact: billingContact) {
                parameters["billing"] = dict
            }
        }
        
        print("url:: \(DemoServerURLBase)")
        print("param:: \(parameters)")

        
        self.hud = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let headers: HTTPHeaders = [
            "Authorization": PASSCODE2,
            "Content-Type": "application/json"
        ]
        
        Alamofire.request(DemoServerURLBase, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers).responseJSON {
            response in
            
            if let _ = self.hud {
                self.hud.hide(animated: true)
            }
            
            var successFlag = false
            var status = "Payment was not processed"
            var json: NSDictionary! = nil
            
            if let result = response.result.value {
                json = result as! NSDictionary
                print("JSON: \(json)")
            }
            
            let statusCode = response.response?.statusCode
            
            if statusCode == 200 {
                successFlag = true
                status = "Payment processed successfully"
            }
            else {
                print("process transaction request error: \(statusCode ?? -1)")
                if let _ = json, let message = json["message"] as! String? {
                    status = message
                }
                else if response.result.isFailure {
                    status = response.result.debugDescription
                }
            }
            
            self.alert = UIAlertController.init(title: "Mobile Payments \(b64TokenStr)", message: status, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: { (alert: UIAlertAction) in
                self.dismiss(animated: true, completion: nil)
            })
            self.alert.addAction(okAction)
            
            if successFlag {
                completion(.success)
            }
            else {
                completion(.failure)
            }
        }
        completion(.success)
    }
    
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didSelect shippingMethod: PKShippingMethod, completion: @escaping (PKPaymentAuthorizationStatus, [PKPaymentSummaryItem]) -> Void) {
        completion(.success, itemToSell(shipping: Double(shippingMethod.amount)))
    }
    
    func paymentAuthorizationViewControllerDidFinish(_ controller: PKPaymentAuthorizationViewController) {
        controller.dismiss(animated: true, completion: nil)
        
        if let _ = self.hud {
            self.hud.hide(animated: true)
        }
        
        if let _ = self.alert {
            self.present(alert, animated: true, completion: nil)
            self.alert = nil
        }
    }
    
    // Returns a dictionary if address info is found else returns nil.
    private func convertToAddressDictionary(contact: PKContact) -> [String:String]? {
        var addressDictionary: [String:String] = Dictionary()
        
        if let address = contact.postalAddress {
            addressDictionary["address_line1"] = address.street
            addressDictionary["province"] = address.state
            addressDictionary["city"] = address.city
            addressDictionary["country"] = address.country
            addressDictionary["postal_code"] = address.postalCode
        }
        
        if let email = contact.emailAddress {
            addressDictionary["email_address"] = email
        }
        
        /*
         // Converts to JSON Data
         do {
         let json = try JSONSerialization.data(withJSONObject: addressDictionary, options: .prettyPrinted)
         return json
         } catch {
         print(error.localizedDescription)
         }
         */
        
        if addressDictionary.count > 0 {
            return addressDictionary
        }
        else {
            return nil
        }
    }
}

