//
//  ViewController.swift
//  ApplePayDemo
//
//  Created by Bandish on 23/11/17.
//  Copyright © 2017 Bandish. All rights reserved.
//

import UIKit
import PassKit

class ViewController: UIViewController {
    var paymentRequest = PKPaymentRequest()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func itemToSell(shipping: Double) -> [PKPaymentSummaryItem]
    {
        let item = PKPaymentSummaryItem(label: "Card amount", amount: 90.00)
        let discount = PKPaymentSummaryItem(label: "Discount", amount: -10.0)
        let shippingCharge = PKPaymentSummaryItem(label: "Shipping", amount: NSDecimalNumber(string: "\(shipping)"))
        let totalAmount = item.amount.adding(discount.amount).adding(shippingCharge.amount)
        let totalPrice = PKPaymentSummaryItem(label: "total amount", amount: totalAmount)
        return [item, discount, shippingCharge, totalPrice]
    }
    
    func paymentProcess() {
        let paymentNetwork = [PKPaymentNetwork.amex, .masterCard, .visa]
        if PKPaymentAuthorizationController.canMakePayments(usingNetworks: paymentNetwork){
            paymentRequest.currencyCode = "USD"
            paymentRequest.countryCode = "US"
            paymentRequest.merchantIdentifier = "merchant.com.gatewaytechnolabs.aromaDemoDev"
            paymentRequest.merchantCapabilities = .capability3DS
            paymentRequest.supportedNetworks = paymentNetwork
            paymentRequest.requiredShippingAddressFields = .all
            paymentRequest.paymentSummaryItems = self.itemToSell(shipping: 9.99)
            
            let sameDayShipping = PKShippingMethod(label: "Same Day Shipping", amount: NSDecimalNumber(string: "20"))
            sameDayShipping.identifier = "sameDayShipping"
            sameDayShipping.detail = "Item guaranteed to deliverd on the same day"
            
            
            let twoDayShipping = PKShippingMethod(label: "twoDayShipping Shipping", amount: NSDecimalNumber(string: "10"))
            twoDayShipping.identifier = "twoDayShipping"
            twoDayShipping.detail = "Arrives in 2 bussiness day"
            
            let freeShipping = PKShippingMethod(label: "Free Shipping", amount: NSDecimalNumber(string: "0"))
            freeShipping.identifier = "freeshipping"
            freeShipping.detail = "Arrives in 6-8 weeks"
            
            paymentRequest.shippingMethods = [sameDayShipping, twoDayShipping, freeShipping]
            
            let applePayVC = PKPaymentAuthorizationViewController(paymentRequest: paymentRequest)
            applePayVC.delegate = self
            self.present(applePayVC, animated: true, completion: nil)
        }
        else {
            let alert = UIAlertController(title: "Demo",
                                          message: "apple pay is not configured or not available",
                                          preferredStyle: UIAlertControllerStyle.alert)
            let cancelAction = UIAlertAction(title: "OK",
                                             style: .cancel, handler: nil)
            alert.addAction(cancelAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnApplePayPressed(_ sender: Any) {
        self.paymentProcess()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
}

extension ViewController: PKPaymentAuthorizationViewControllerDelegate{
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didAuthorizePayment payment: PKPayment, completion: @escaping (PKPaymentAuthorizationStatus) -> Void) {
        completion(.success)
    }
    
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didSelect shippingMethod: PKShippingMethod, completion: @escaping (PKPaymentAuthorizationStatus, [PKPaymentSummaryItem]) -> Void) {
        completion(.success, itemToSell(shipping: Double(shippingMethod.amount)))
    }
    
    func paymentAuthorizationViewControllerDidFinish(_ controller: PKPaymentAuthorizationViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
}

